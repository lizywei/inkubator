# INKubator Agentic Demo (NVIDIA AIQ Toolkit Hackathon)

> A local AI agent system to help writers publish ethically and creatively using NVIDIA tools.

---

## 🔥 Overview

This demo showcases a lightweight, three-agent architecture that:
- 📚 Curates story submissions with suggested headlines, tags, and excerpts
- 🛡 Moderates for unsafe or policy-violating content
- 💸 Simulates tipping and unlocks premium content for readers

All agents are powered by simple Python, NVIDIA’s AIQ Toolkit-compatible architecture, and run locally on an RTX 5880.

---

## 💼 Folder Structure

```bash
inkubator-agents-demo/
├── agents/
│   ├── curation_agent.py
│   ├── moderation_agent.py
│   └── transaction_agent.py
├── data/
│   ├── Diane_Goodlett_Chapter_1.txt
│   ├── Isla_Lane_Chapter_1.txt
│   ├── writer-diane_goodlett-ch1.pdf
│   ├── writer-DataPoisoning-chapter-1.pdf
│   └── tip_log.json
├── README.md
├── LICENSE
```

---

## 🚀 How to Run (Step-by-Step)

1. Make sure you have Python 3.10+ installed.
2. Clone this repo or unzip the package.
3. Navigate to the folder:
```bash
cd inkubator-agents-demo
```
4. Run each agent:
```bash
python3 agents/curation_agent.py
python3 agents/moderation_agent.py
python3 agents/transaction_agent.py
```

---

## 🧠 Agent Details

### 🧠 Curation Agent
Suggests:
- `Headline`
- `Tag`
- `Excerpt`
Based on vector search (FAISS-ready pipeline).

### 🛡 Moderation Agent
Checks for:
- Unsafe content
- Basic keyword-based screening (extendable to embedding similarity)

### 💸 Transaction Agent
- Simulates tipping and access
- Logs tip in `tip_log.json`
- Unlocks content preview

---

## 🧰 Tech Stack

- Python 3.10
- NVIDIA AIQ-compatible design
- HuggingFace / FAISS (optionally)
- Runs fully offline (no S3, no OpenAI, no API keys)

---

## 🧑‍🎤 Credit

Built by **Liz Otero**, Founder & CEO, WEI Robotics LLC  
INKubator™ is a registered trademark.  
MIT License — see LICENSE file for details.

---

## 🏁 Demo Video

> Available in `demo.mp4`  
> Voiceover generated using natural language synthesis  
> Screen captured using OBS Studio
